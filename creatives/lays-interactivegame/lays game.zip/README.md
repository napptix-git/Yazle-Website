# Lays Catch & Collect Game - How to Run

An interactive browser-based game where players catch falling Lays chips to earn points!

## 🚨 IMPORTANT: Do NOT double-click index.html directly!

Modern browsers block loading of CSS/JS files when opening HTML files directly from the file system (file:// protocol) due to CORS security policies. **A local web server is required.**

---

## How to Run This Game

Follow these steps to run the game properly:

### STEP 1: Extract the Files
1. Extract the game folder to a location on your computer
2. The folder name can be anything (e.g., `lays-game` or `Catch-to-collect`)
3. Remember the folder location

### STEP 2: Open Terminal in the Extracted Folder

**Windows:**
- Right-click inside the folder → Select "Open in Terminal"
- OR Shift + Right-click → Select "Open PowerShell window here"

**Mac:**
- Right-click inside the folder → Select "New Terminal at Folder"
- OR navigate using: `cd /path/to/your/folder`

**Linux:**
- Right-click inside the folder → Select "Open in Terminal"
- OR navigate using: `cd /path/to/your/folder`

### STEP 3: Choose Your Method

#### **OPTION 1 - Python (Recommended)**
1. With terminal open in the extracted folder, run:
   ```bash
   python -m http.server 8080
   ```
   Or if you have Python 2:
   ```bash
   python -m SimpleHTTPServer 8080
   ```
2. Open your browser to: **http://localhost:8080**
3. The game will load automatically!

#### **OPTION 2 - Node.js**
1. With terminal open in the extracted folder, run:
   ```bash
   npx serve .
   ```
2. Open the URL shown in terminal (usually http://localhost:3000)

#### **OPTION 3 - VS Code Live Server**
1. Open the extracted folder in VS Code (File → Open Folder)
2. Install "Live Server" extension (if not already installed)
   - Click Extensions icon (Ctrl+Shift+X)
   - Search for "Live Server"
   - Click Install
3. Right-click on `index.html` → "Open with Live Server"
4. Game opens in your default browser

### WHY THIS IS NEEDED:
Modern browsers block loading of CSS/JS files when opening HTML files directly from the file system (file:// protocol) due to CORS security policies. A local web server is required.

---

## 📱 For Best Mobile Experience (Highly Recommended!)

To see the game as it would appear on a real mobile device, use this Chrome extension:

### **Mobile Simulator - Responsive Testing Tool**

**🔗 Install here:** [Chrome Web Store - Mobile Simulator](https://chromewebstore.google.com/detail/mobile-simulator-responsi/ckejmhbmlajgoklhgbapkiccekfoccmk)

#### Why Use This Extension?
- ✅ **Perfect mobile preview** - See exactly how it looks on iPhone, Samsung, etc.
- ✅ **Touch simulation** - Test drag controls as on real phones
- ✅ **Multiple device presets** - iPhone 14, Samsung Galaxy, iPad, and more
- ✅ **Instant testing** - Switch between devices quickly
- ✅ **Professional results** - See the game in a realistic phone frame

#### How to Use:
1. Install the extension from the Chrome Web Store (link above)
2. Start the game using one of the options above
3. Click the Mobile Simulator extension icon in your browser toolbar
4. Select a device preset (recommended: **iPhone 14 Pro - 393 × 852**)
5. The game displays in a mobile phone frame
6. Test by clicking and dragging just like on a real phone

#### Recommended Devices:
- **iPhone 14 Pro** (393 × 852) - Optimal experience
- **iPhone 13** (390 × 844) - Standard gameplay
- **Samsung Galaxy S21** (360 × 800) - Android view

---

## 🎯 How to Play

1. **Start**: Click the orange "Play" button on the start screen
2. **Move Cart**:
   - **Desktop**: Click and drag the shopping cart left/right with mouse
   - **Mobile/Simulator**: Touch and drag the cart with your finger
3. **Catch Chips**: Position the cart under falling Lays chips to catch them
4. **Score**: Each chip caught = 1 point
5. **Timer**: You have **15 seconds** to catch as many chips as possible
6. **Win**: High scores earn you the "Snack Master" title!

### Controls:
- **Desktop**: Mouse click + drag
- **Mobile**: Touch + drag
- Cart automatically stays within game boundaries

## 📁 Project Structure

```
Catch-to-collect/
├── index.html          # Main HTML file
├── style.css           # All styling and animations
├── script.js           # Game logic and interactions
├── README.md           # This file
└── assets/             # Game assets folder
    ├── cart.png
    ├── shelf.png
    ├── LAYS.png
    ├── lays poster.png
    ├── overlay2-1.png
    ├── Gemini_Generated_Image_uzrf0vuzrf0vuzrf.png
    ├── Lays-Logo-PNG-Picture.png
    └── [Various Lays chip images]
```

## 🛠️ Technical Details

### Technologies Used:
- **HTML5** - Structure and layout
- **CSS3** - Styling, animations, and responsive design
- **Vanilla JavaScript** - Game logic, no frameworks
- **CSS Flexbox** - Responsive positioning
- **RequestAnimationFrame** - Smooth animations
- **Touch Events API** - Mobile support

### Browser Compatibility:
- ✅ Chrome (recommended)
- ✅ Firefox
- ✅ Safari
- ✅ Edge
- ✅ Mobile browsers (iOS Safari, Chrome Mobile)

### Performance:
- Optimized for 60 FPS
- Lightweight (< 5MB total)
- Fast load times
- Smooth animations

## 🎨 Customization

### Change Game Duration:
Edit `script.js` line 10:
```javascript
let timeLeft = 15; // Change to desired seconds
```

### Adjust Item Fall Speed:
Edit `script.js` line 216:
```javascript
let speed = 5; // Increase for faster, decrease for slower
```

### Modify Item Spawn Rate:
Edit `script.js` line 27:
```javascript
gameInterval = setInterval(makeItemFall, 1000); // Time in milliseconds
```

## 🐛 Troubleshooting

### Images not loading?
- Ensure all files are in the correct folders
- Check that image paths in code match your file structure
- Use a local server instead of opening HTML directly

### Cart not moving smoothly?
- Check browser console for errors (F12)
- Try using the Mobile Simulator extension
- Ensure JavaScript is enabled

### Game not responsive on mobile?
- Use the recommended Mobile Simulator extension
- Clear browser cache
- Check viewport meta tag in `index.html`

## 📄 License

This is a branded game for Lays chips. All Lays branding, logos, and trademarks are property of PepsiCo/Frito-Lay.

## 🤝 Support

For issues or questions:
- Check the Troubleshooting section above
- Review the code comments in each file
- Test with the Mobile Simulator extension

## 🎉 Have Fun!

Enjoy catching those chips and becoming a Snack Master! 🍟

---

**Made with ❤️ for Lays enthusiasts everywhere!**
