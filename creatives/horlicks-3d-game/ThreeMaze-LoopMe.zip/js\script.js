//https://darkstarhub.github.io/ThreeMaze/

//#region LoopMe Integration

// LoopMe ClickTag Integration
function getParameterByName(name) {
    const url = window.location.href;
    name = name.replace(/[\[\]]/g, '\\$&');
    const regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)');
    const results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}

const clickTag = getParameterByName('clickTag') || 'https://www.horlicks.in/';

function handleClickThrough() {
    console.log('[LoopMe] ClickThrough to:', clickTag);
    // Track clickthrough event
    trackEvent('clickthrough');
    // Open the clickTag URL
    window.open(clickTag, '_blank');
}

// LoopMe Tracking Integration
let hasTrackedFirstInteraction = false;

function trackEvent(eventName, eventData = {}) {
    console.log(`[LoopMe Track] ${eventName}`, eventData);

    // LoopMe tracking (if SDK is loaded)
    if (typeof LoopMeTrack !== 'undefined') {
        try {
            LoopMeTrack(eventName, eventData);
        } catch (e) {
            console.warn('[LoopMe Track] LoopMeTrack failed:', e);
        }
    }

    // Alternative: Use postMessage for LoopMe container
    if (window.parent !== window) {
        try {
            window.parent.postMessage({
                type: 'loopme_event',
                event: eventName,
                data: eventData
            }, '*');
        } catch (e) {
            console.warn('[LoopMe Track] postMessage failed:', e);
        }
    }
}

function trackFirstInteraction() {
    if (!hasTrackedFirstInteraction) {
        hasTrackedFirstInteraction = true;
        trackEvent('first_interaction', {
            timestamp: Date.now()
        });
    }
}

// Detect if running in LoopMe ad environment
const isLoopMeAd = getParameterByName('loopme') === 'true' ||
                   window.location.href.includes('loopme') ||
                   window.self !== window.top; // Running in iframe

// Quick play settings for ads
const QUICK_PLAY_MODE = isLoopMeAd;
const COLLECTIBLES_REQUIRED = 3;  // Need to collect 3 wholesome items (1 of each type) to unlock portal

console.log('[LoopMe] Quick Play Mode:', QUICK_PLAY_MODE);
console.log('[LoopMe] Collectibles Required:', COLLECTIBLES_REQUIRED);

// Hologram Click Detection for LoopMe CTA
const holoRaycaster = new THREE.Raycaster();
const holoPointer = new THREE.Vector2();
let onIsland = false;

function onCanvasClick(event) {
  // Only check for hologram clicks when on island
  if (!onIsland || !window.productHologram || !window.productHologram.visible) return;

  // Get the correct coordinates for touch or mouse events
  const clientX = event.touches ? event.touches[0].clientX : event.clientX;
  const clientY = event.touches ? event.touches[0].clientY : event.clientY;

  // Calculate mouse position in normalized device coordinates (-1 to +1)
  holoPointer.x = (clientX / window.innerWidth) * 2 - 1;
  holoPointer.y = -(clientY / window.innerHeight) * 2 + 1;

  // Update raycaster
  holoRaycaster.setFromCamera(holoPointer, camera);

  // Check for intersections with the hologram
  const intersects = holoRaycaster.intersectObject(window.productHologram, true);

  if (intersects.length > 0) {
    console.log('[LoopMe] Hologram clicked!');
    HideIslandMessage(); // Hide the message when user clicks
    handleClickThrough();
  }
}

//#endregion LoopMe Integration

//#region Init
////imports=======================================================
////greensock import

const gsap = window.gsap;
//const datG = window.dat.gui;
const sizes = {width:window.innerWidth,height:window.innerHeight};
//const dGui = new dat.GUI();
////imports=======================================================





////create scene==================================================================
const scene = new THREE.Scene();
////create scene==================================================================




////create camera==================================================================
const camera = new THREE.PerspectiveCamera( 60,sizes.width/sizes.height);
camera.position.z = 15; //5
camera.position.x = 5; //0
camera.position.y = 12; //5.7

camera.rotateX((Math.PI/180)*-25);

//camera.lookAt(new THREE.Vector3())
////create camera==================================================================



////create canvas==================================================================
const canvas = document.querySelector('canvas.webgl');
////create canvas==================================================================




////create renderer==================================================================
// LoopMe-compliant renderer setup
const renderer = new THREE.WebGLRenderer({
  canvas: canvas,
  antialias: true,
  powerPreference: 'high-performance',  // Mobile optimization
  alpha: false,                          // Opaque background = better perf
  preserveDrawingBuffer: false
});
renderer.setSize(sizes.width, sizes.height);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

// Mobile-optimized shadow and color settings
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 0.2;
renderer.outputColorSpace = THREE.SRGBColorSpace;
////create renderer==================================================================




////browser resizing==================================================================
// LoopMe-compliant responsive resize handler
function resizeRenderer() {
  const width = window.innerWidth;
  const height = window.innerHeight;

  sizes.width = width;
  sizes.height = height;

  // Dynamic FOV for mobile screens (wider FOV on small screens)
  camera.aspect = width / height;
  camera.fov = Math.max(50, 90 - (width / 20)); // iPhone SE baseline
  camera.updateProjectionMatrix();

  renderer.setSize(width, height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
}

window.addEventListener('resize', resizeRenderer);

// LoopMe requirement: Handle orientation changes on mobile
window.addEventListener('orientationchange', () => setTimeout(resizeRenderer, 100));

// Settings menu removed - commenting out menu positioning code
// if(gearsOpen)
// {
//   let x = window.innerWidth;
//   let y = window.innerHeight;
//
//   if(window.innerWidth>window.innerHeight)
//   {
//     gsap.to(optionsBar, {y: window.innerWidth *.2, duration: 0});
//     return;
//   }
//
//   gsap.to(optionsBar, {y: window.innerWidth *.8, duration: 0});
// }
////browser resizing==================================================================




////stats=========================================================
// Stats removed to reduce file size for ad platform deployment
// function createStats()
// {
//   var stats = new Stats();
//   stats.setMode(0);
//   stats.domElement.style.position = 'absolute';
//   stats.domElement.style.left = '0';
//   stats.domElement.style.top = '0';
//   return stats;
// }
////stats=========================================================
////for stats
// stats = createStats();
// document.body.appendChild( stats.domElement );
//#endregion Init




//#region Variables
//maze variables
const mWidth = QUICK_PLAY_MODE ? 4 : 4;  // 4x4 maze
const mLength = QUICK_PLAY_MODE ? 4 : 4;

const exitX = Math.floor((Math.random() * mWidth));
const exitY = mLength-1;

const entX = 1;
const entY = 0;


let curX = 1;
let curY = 0;
let curTile = 0;

let neighborCount = 0;


let cellArrayNew = [];//values per wall-  1 south, 2 west, 4 north, 8 east

let Visited = [];
let theStack = [];

let recSteps = 0;


let longestDistance = 0;
let furthestPoint = 0;




//environment
let envTexNum = 0;


//gameloop update arrays
const objectsToUpdate = [];
const trapsToUpdate = [];


let trapsOut = false;


let currentAction;


let aniMixers = [];
let trapArr = [];


let pCurTexNum = 0;



//player variables
let playerObj = null;
let camSpot = null;
let charBody = null;

const skeleAnimArr = [];

let skeleMixer;

let idleAction,runAction;

let curAction = 100;

const idleAnimPath = 'assets/Skele/idle_1_male_free_animation_200_frames_loop.glb';
const runAnimPath = 'assets/Skele/male_running_20_frames_loop.glb';



// Lives system
let playerLives = 3;
const maxLives = 3;
let isInvulnerable = false;
const invulnerabilityDuration = 1000; // 1 second after hit

// Collectibles system (wholesome items vs hazards)
const collectibleConfig = {
  wholesomeTypes: ['almond', 'millet', 'oats'],
  hazardTypes: ['fries', 'cola'],
  wholesomeTarget: 3,  // 3 wholesome collectibles spawn (1 of each type)
  hazardCount: 2       // 2 junk foods spawn
};
let wholesomeCollected = 0;
const wholesomeCollectibles = [];
const hazardCollectibles = [];
const pendingCollectibles = [];

let portalUnlocked = false;
let portalObject = null;
let portalBody = null;
let portalLight = null;
let portalPosition = { x: 0, y: 0, z: 0 };
let portalArrow = null;

//#endregion Variables




//#region loading region

//create all loaders
const loadingManager = new THREE.LoadingManager();

const textureLoader = new THREE.TextureLoader(loadingManager);
const gltfLoader = new GLTFLoader();
// Draco loader (LoopMe-safe relative path)
if (THREE.DRACOLoader) {
  try {
    const dracoLoader = new THREE.DRACOLoader();
    dracoLoader.setDecoderPath('./js/draco/'); // relative to index.html for packaged creatives
    gltfLoader.setDRACOLoader(dracoLoader);
  } catch (e) {
    console.warn('[Draco] Failed to initialize DRACOLoader; Draco GLBs may not load.', e);
  }
} else {
  console.warn('[Draco] DRACOLoader not found; Draco-compressed models will not load.');
}
// Create procedural almond geometry (saves 1.07MB!)
let almondModel = null;
let almondReady = false;

// Create almond-shaped geometry using stretched sphere
const almondGeometry = new THREE.SphereGeometry(0.9, 16, 12);
// Stretch to almond shape: wider at middle, pointy at ends
const positions = almondGeometry.attributes.position;
for (let i = 0; i < positions.count; i++) {
  const y = positions.getY(i);
  const x = positions.getX(i);
  const z = positions.getZ(i);
  // Stretch vertically and taper at ends
  const taperFactor = 1 - Math.abs(y) * 0.3;
  positions.setX(i, x * taperFactor * 0.6);
  positions.setZ(i, z * taperFactor * 0.6);
  positions.setY(i, y * 1.4); // Make it taller/elongated
}
positions.needsUpdate = true;
almondGeometry.computeVertexNormals();

// Brown almond color with slight texture variation
const almondMaterial = new THREE.MeshStandardMaterial({
  color: 0x8B6F47, // Almond brown color
  roughness: 0.8,
  metalness: 0.1,
  flatShading: false
});

const almondMesh = new THREE.Mesh(almondGeometry, almondMaterial);
almondMesh.castShadow = true;
almondMesh.receiveShadow = true;
almondMesh.scale.set(1, 1, 1);

almondModel = new THREE.Object3D();
almondModel.add(almondMesh);
almondModel.scale.setScalar(0.55); // Reduced from 1.8 to 0.8 for smaller size
almondReady = true;

// Spawn any pending collectibles now that almond is ready
spawnPendingCollectibles();

//load textures
const bgTexture = textureLoader.load('assets/bg.jpg');



const mainTexture = textureLoader.load('assets/Walls/MainText.fw.webp');
mainTexture.flipY = false;// this might not work, cause texture isn't loaded
mainTexture.encoding = THREE.sRGBEncoding;// this might not work, cause texture isn't loaded

const portTex = textureLoader.load('assets/fxDot.webp');
const ringTex = textureLoader.load('assets/fxRing.webp');

// Skeleton textures removed - no longer needed
// const playerBase = textureLoader.load('assets/Skele/baseSkel.jpg');
// playerBase.flipY = false;
// playerBase.encoding = THREE.sRGBEncoding;

// const playerRed = textureLoader.load('assets/Skele/sk_red.webp');
// playerRed.flipY = false;
// playerRed.encoding = THREE.sRGBEncoding;

// const playerBlue = textureLoader.load('assets/Skele/sk_blue.webp');
// playerBlue.flipY = false;
// playerBlue.encoding = THREE.sRGBEncoding;

// const playerGreen = textureLoader.load('assets/Skele/sk_green.webp');
// playerGreen.flipY = false;
// playerGreen.encoding = THREE.sRGBEncoding;





// HDR environment removed to reduce file size
// const dayEnvTex = rLoader.load('assets/HDR29.hdr', function()
// {
//     dayEnvTex.mapping = THREE.EquirectangularReflectionMapping;
//     renderer.initTexture(dayEnvTex);
//     //scene.background = texture;
//     //scene.environment = dayEnvTex;
//     //scene.envMapIntensity = 5;
// });

// LoopMe-optimized mobile lighting (NO HDR/IBL for performance)
const ambientLight = new THREE.AmbientLight(0x404040, 0.12);
scene.add(ambientLight);

// HemisphereLight for natural sky/ground color gradient
const hemiLight = new THREE.HemisphereLight(0x87CEEB, 0x443333, 0.15);
scene.add(hemiLight);

// Directional light with mobile-optimized shadow maps
const directionalLight = new THREE.DirectionalLight(0xffffff, 0.25);
directionalLight.position.set(5, 10, 7.5);
directionalLight.castShadow = true;
directionalLight.shadow.mapSize.width = 1024;  // Mobile-friendly shadow resolution
directionalLight.shadow.mapSize.height = 1024;
directionalLight.shadow.camera.near = 0.5;
directionalLight.shadow.camera.far = 50;
scene.add(directionalLight);

// Environment switching disabled for LoopMe (only day environment kept)
// const duskEnvTex = rLoader.load('assets/Dusk.hdr', function()
// {
//     duskEnvTex.mapping = THREE.EquirectangularReflectionMapping;
//     renderer.initTexture(duskEnvTex);
//     //scene.environment = duskEnvTex;
// });
// const nightEnvTex = rLoader.load('assets/Night.hdr', function()
// {
//     nightEnvTex.mapping = THREE.EquirectangularReflectionMapping;
//     renderer.initTexture(nightEnvTex);
//     //scene.environment = nightEnvTex;
// });





//create materials
const lightStoneMat = new THREE.MeshStandardMaterial({
    color: '#ffffff'
});
const tileMat = new THREE.MeshStandardMaterial({
    color: '#dddddd'
});
const mainMat = new THREE.MeshStandardMaterial({
    /*color: '#cccccc'*/
    map: mainTexture,
    /*emissive: '#242424'*/
});  
const wallMat = new THREE.MeshStandardMaterial({
    color: '#cccccc'  
});







const startEnv = 0; // Always day time

// Set to day environment only
scene.background = bgTexture;
// scene.environment = dayEnvTex; // Commented - HDR removed for size optimization








//#endregion loading region




//#region Audio - DISABLED FOR LOOPME (Size optimization)
// Audio removed to reduce file size for ad platform deployment
//#endregion Audio

// Audio disabled for LoopMe
// window.addEventListener('blur',()=>
// {
//  Howler.mute(true);
// });
// window.addEventListener('focus',()=>
// {
//  Howler.mute(false);
// });



//#region Physics
//physics
const world = new CANNON.World();

//// cannon debugger
//const cannonDebugger = new CannonDebugger(scene,world);

world.broadPhase = new CANNON.SAPBroadphase(world);
//world.allowSleep = true;
world.gravity.set(0,-9.82,0);



const NWshape = new CANNON.Box(new CANNON.Vec3(.48,2.5,5));  
const tileShape = new CANNON.Box(new CANNON.Vec3(5,.5,5));  
const EWshape = new CANNON.Box(new CANNON.Vec3(.48,2.5,5));  
const pillarShape = new CANNON.Box(new CANNON.Vec3(.6,2.5,.6));  

const clapTrapShape = new CANNON.Box(new CANNON.Vec3(4.25,2.05,.5));


//physics
//#endregion Physics





function LoadAll()
{    
  gltfLoader.load(    
    'assets/Walls/pillar444.glb',
    (gltf) =>
    {      
      instancedPost = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, lightStoneMat, 121);   
      scene.add(instancedPost); 
      CreateTileInstancesChain()// tiles when posts done
    }); 
}

function CreateTileInstancesChain()
{
  gltfLoader.load(    
    'assets/Walls/tile111tx.glb',
    (gltf) =>
    {         
      iTile1 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, tileInstCount); 
      scene.add(iTile1);//tile 1 done 
      //load tile 2
      gltfLoader.load(    
        'assets/Walls/tile222tx.glb',
        (gltf) =>
        {      
          iTile2 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, tileInstCount);      
          scene.add(iTile2); //tile 2 done
          //load tile 3
          gltfLoader.load(    
            'assets/Walls/tile333tx.glb',
            (gltf) =>
            {      
              iTile3 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, tileInstCount);      
              scene.add(iTile3);//tile 3 done 
              //load tile 4
              gltfLoader.load(    
                'assets/Walls/tile444tx.glb',
                (gltf) =>
                {      
                  iTile4 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, tileInstCount);      
                  scene.add(iTile4);//tile 4 done
                  // call something else  
                CreateWallInstanceChain();
                });         
            });
        });
      });
}

function CreateWallInstanceChain()
{
  gltfLoader.load(    
    'assets/Walls/wall1111.glb',
    (gltf) =>
    {       
      instancedWall1 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, wallInstCount);  
      //instancedWall1 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, wallMat, wallInstCount); 
      scene.add(instancedWall1);// wall 1 loaded
      //load wall 2
    gltfLoader.load(    
        'assets/Walls/wall2222.glb',
        (gltf) =>
        {      
            instancedWall2 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, wallInstCount);      
            scene.add(instancedWall2);// wall 2 loaded
            //load wall 3
            gltfLoader.load(    
            'assets/Walls/wall3333.glb',
            (gltf) =>
            {      
                instancedWall3 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, wallInstCount);      
                scene.add(instancedWall3);// wall 3 loaded
                //load wall 4
                gltfLoader.load(    
                    'assets/Walls/wall4444.glb',
                    (gltf) =>
                    {      
                        instancedWall4 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, wallInstCount);      
                        scene.add(instancedWall4);// wall 4 loaded
                        //do something else  
                        CalculateMaze();        
                    });      
            });     
        });        
    });  
}





//#region Build out
function BuildTile(xPos,zPos,incCellObj)
{    

    AddTileInstance(xPos,zPos);//xPos*10, 0, (zPos*10)*-1  

    const body = new CANNON.Body({
        mass: 0,
        position: new CANNON.Vec3((xPos*10),-.5,(zPos*10)*-1),      
        shape: tileShape,        
    });         
    world.addBody(body);   
    incCellObj.tileCol = body; 
}


function BuildTileNoMaze(xPos,zPos)
{    
  const num = Math.floor((Math.random() * 4));
  let loadString = 'assets/Walls/tile111tx.glb';
  switch(num)
  {    
    case 0:    
    loadString = 'assets/Walls/tile111tx.glb'
    break;
    
    case 1:      
    loadString = 'assets/Walls/tile222tx.glb'
    break;

    case 2:     
    loadString = 'assets/Walls/tile333tx.glb'  
    break;

    case 3:      
    loadString = 'assets/Walls/tile444tx.glb' 
    break;
  }
  gltfLoader.load(
    //'assets/fTile2.gltf',
    loadString,
    (gltf) =>
    {      
      const newTile = gltf.scenes[0].children[0];
      newTile.material = mainMat;
      newTile.position.x = xPos*10;
      newTile.position.y = 0;
      newTile.position.z = (zPos*10)*-1;    
      newTile.scale.set(1,1,1);          
      scene.add(newTile);
                     
      
      const body = new CANNON.Body({
      mass: 0,
      position: new CANNON.Vec3(newTile.position.x,newTile.position.y-.5,newTile.position.z),      
      shape: tileShape,      
      });      
     
      world.addBody(body);   
    }
  );
}






//instances===================================================

const dummyObj = new THREE.Object3D();//new for instancing
var instancedPost;

const dummyTileObj = new THREE.Object3D();//new for instancing
var iTile1,iTile2,iTile3,iTile4

const dummyWallObj = new THREE.Object3D();//new for instancing
const dummyEWallObj = new THREE.Object3D();//new for instancing
var instancedWall1,instancedWall2,instancedWall3,instancedWall4;


const tileIndexArray = [0,0,0,0];
const tileInstCount = 25;
const wallIndexArray = [0,0,0,0];
const wallInstCount = 30;

  
function CreatePostInstance()
{
  gltfLoader.load(    
    'assets/Walls/pillar444.glb',
    (gltf) =>
    {       
      instancedPost = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, lightStoneMat, 121);   
      scene.add(instancedPost); 
    });    
}

function AddPostInstance(xPos,zPos)
{      
  //for instancing
    dummyObj.position.set((xPos*10)-5, 0, ((zPos*10)-5)*-1); 
    dummyObj.rotation.x = Math.PI / 2;
    dummyObj.updateMatrix();    
    instancedPost.setMatrixAt((xPos*(mWidth+1))+zPos, dummyObj.matrix); 
    instancedPost.instanceMatrix.needsUpdate = true;
  //for instancing


  const body = new CANNON.Body({
    mass: 0,    
    position: new CANNON.Vec3(dummyObj.position.x,2.5,dummyObj.position.z),
    shape: pillarShape,    
    });    
    world.addBody(body);
}


function CreateTileInstances()
{
    gltfLoader.load(    
        'assets/Walls/tile111tx.glb',
        (gltf) =>
        {           
          iTile1 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, tileInstCount); 
          scene.add(iTile1);         
        });
    gltfLoader.load(    
        'assets/Walls/tile222tx.glb',
        (gltf) =>
        {      
          iTile2 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, tileInstCount);      
          scene.add(iTile2);       
        });
    gltfLoader.load(    
        'assets/Walls/tile333tx.glb',
        (gltf) =>
        {      
          iTile3 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, tileInstCount);      
          scene.add(iTile3);     
        });
    gltfLoader.load(    
        'assets/Walls/tile444tx.glb',
        (gltf) =>
        {      
          iTile4 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, tileInstCount);      
          scene.add(iTile4);             
        });
}

function AddTileInstance(xPos,zPos)
{
    dummyTileObj.position.set(xPos*10, 0, (zPos*10)*-1);  
    dummyTileObj.rotation.x = Math.PI / 2;
    
    dummyTileObj.updateMatrix();
    let tNum = Math.floor((Math.random() * 4));    
    let fNum = FindValidIndex(tNum,tileIndexArray,tileInstCount);
    

  switch(fNum)
  {    
    case 0:
    iTile1.setMatrixAt(tileIndexArray[0], dummyTileObj.matrix); 
    iTile1.instanceMatrix.needsUpdate = true;
    tileIndexArray[0]++;     
    break;
    
    case 1:      
    iTile2.setMatrixAt(tileIndexArray[1], dummyTileObj.matrix); 
    iTile2.instanceMatrix.needsUpdate = true;
    tileIndexArray[1]++;
    break;

    case 2:     
    iTile3.setMatrixAt(tileIndexArray[2], dummyTileObj.matrix); 
    iTile3.instanceMatrix.needsUpdate = true;
    tileIndexArray[2]++;
    break;

    case 3:      
    iTile4.setMatrixAt(tileIndexArray[3], dummyTileObj.matrix); 
    iTile4.instanceMatrix.needsUpdate = true;
    tileIndexArray[3]++;
    break;
  }
}



function CreateWallInstances()
{
  gltfLoader.load(    
    'assets/Walls/wall1111.glb',
    (gltf) =>
    {       
      instancedWall1 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, wallInstCount);      
      scene.add(instancedWall1);         
    });
  gltfLoader.load(    
    'assets/Walls/wall2222.glb',
    (gltf) =>
    {      
      instancedWall2 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, wallInstCount);      
      scene.add(instancedWall2);       
    });
  gltfLoader.load(    
    'assets/Walls/wall3333.glb',
    (gltf) =>
    {      
      instancedWall3 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, wallInstCount);      
      scene.add(instancedWall3);     
    });
  gltfLoader.load(    
    'assets/Walls/wall4444.glb',
    (gltf) =>
    {      
      instancedWall4 = new THREE.InstancedMesh(gltf.scenes[0].children[0].geometry, mainMat, wallInstCount);      
      scene.add(instancedWall4);          
    });
}


function AddNWallInstance(xPos,zPos,turn)// turn 1 is nWall 
{     
  dummyWallObj.position.set(xPos*10,0,((zPos*10)*-1)-5);      
  dummyWallObj.rotation.x = Math.PI / 2;    
   
  dummyWallObj.updateMatrix();
  const wallNum = Math.floor((Math.random() * 4));     
  let fWNum = FindValidIndex(wallNum,wallIndexArray,wallInstCount);

  switch(fWNum)
  {    
    case 0:
    instancedWall1.setMatrixAt(wallIndexArray[0], dummyWallObj.matrix); 
    instancedWall1.instanceMatrix.needsUpdate = true;
    wallIndexArray[0]++;
    break;
    
    case 1:      
    instancedWall2.setMatrixAt(wallIndexArray[1], dummyWallObj.matrix); 
    instancedWall2.instanceMatrix.needsUpdate = true;
    wallIndexArray[1]++
    break;

    case 2:     
    instancedWall3.setMatrixAt(wallIndexArray[2], dummyWallObj.matrix); 
    instancedWall3.instanceMatrix.needsUpdate = true;
    wallIndexArray[2]++
    break;

    case 3:      
    instancedWall4.setMatrixAt(wallIndexArray[3], dummyWallObj.matrix); 
    instancedWall4.instanceMatrix.needsUpdate = true;
    wallIndexArray[3]++
    break;
  }
}

function AddEWallInstance(xPos,zPos,turn)// turn 1 is nWall 
{        
  dummyEWallObj.rotation.x = Math.PI / 2;          
  dummyEWallObj.position.set((xPos*10)+5, 0, (zPos*10)*-1);    
  dummyEWallObj.rotation.z = Math.PI / 2;
    
  dummyEWallObj.updateMatrix();
  const wallNum = Math.floor((Math.random() * 4));   
  let fWNum = FindValidIndex(wallNum,wallIndexArray,wallInstCount);  

  switch(fWNum)
  {    
    case 0:
    instancedWall1.setMatrixAt(wallIndexArray[0], dummyEWallObj.matrix); 
    instancedWall1.instanceMatrix.needsUpdate = true;
    wallIndexArray[0]++;
    break;
    
    case 1:      
    instancedWall2.setMatrixAt(wallIndexArray[1], dummyEWallObj.matrix); 
    instancedWall2.instanceMatrix.needsUpdate = true;
    wallIndexArray[1]++
    break;

    case 2:     
    instancedWall3.setMatrixAt(wallIndexArray[2], dummyEWallObj.matrix); 
    instancedWall3.instanceMatrix.needsUpdate = true;
    wallIndexArray[2]++
    break;

    case 3:      
    instancedWall4.setMatrixAt(wallIndexArray[3], dummyEWallObj.matrix); 
    instancedWall4.instanceMatrix.needsUpdate = true;
    wallIndexArray[3]++
    break;
  }
}

function FindValidIndex(arrPos,arr,count)
{ 
  let found = false;

  if(arr[arrPos]<count)
  {    
    return arrPos;// index is ok
  }
  
  //index is not ok from here.. find a valid, or null
  let loopArrPos = arrPos+1; 
  if(loopArrPos> (arr.length-1))
  {
     loopArrPos = 0;                
  }

  // run a for loop here
  for(let i =0; i<arr.length;i++)
  {      

    if(arr[loopArrPos]<count)
    {
      found = true;     
      return loopArrPos;// index is ok
      break;
    }

    loopArrPos++;// go to next
    if(loopArrPos> (arr.length-1))
    {
     loopArrPos = 0;                
    }    
  }

  if(found == false)
  {    
    return null;
  }      
}

//instances===============================


 



//this will call calcLoop 
function CalculateMaze()
{    
  curTile = (curX*mWidth)+curY;   
  for(let row = 0; row<mWidth; row++)
  {
    for(let column = 0; column<mLength; column++)
    { 
      let colObj = {
        //cellG: cellGroup,
        tileObj: 1,
        nwObj: 1,
        ewObj: 1,
        tileCol: null,
        nwCol: null,
        ewCol: null,
        tileTypeId: 15,
        tileOccupantId: 0
      };      
      cellArrayNew.push(colObj);
    }    
  } 
   Visited.push(curTile);
   theStack.push(curTile);   
   

  CalcLoop();
}
//calls popwalls
function CalcLoop()
{
  const prev = curTile;    

  CalcProbeNeighbor();    
  if(neighborCount>0) //can move forward
  {
    CalcTakeAStep();
    CheckFurthestPoint();
    recSteps = 0;
  }

  if(neighborCount == 0) //recurse
  {        
    theStack.pop();    
    if(theStack.length>0)
    {
      curTile = theStack[theStack.length-1];
      curX = Math.floor(curTile/mWidth);
      curY = (curTile%mWidth);
      recSteps++;
    }
  }  
  
  if(theStack.length>0)
  {
    CalcLoop();
    return;
  }
  if(theStack.length == 0)
  {
    const furX = Math.floor(furthestPoint/mWidth);
    const furY = (furthestPoint%mWidth);

    const endCellFacing = cellArrayNew[furX*mWidth+furY].tileTypeId;    
    
    //place portal here
    BuildPortal(furX,furY,endCellFacing);
 
    
    PopWalls();
  }
}

function CreatePortalFX(xPos,yPos,zPos)
{
    const points = [];
    points.push(new THREE.Vector3(0, 0, 0)); 
    portalGeo = new THREE.BufferGeometry().setFromPoints(points);

    portMat = new THREE.PointsMaterial(
    {      
      opacity: .5,
      color: 0x00ff00,
      map: portTex,
      size: 5.6,
      sizeAttenuation: true,
      transparent: true
    });

    ringMat = new THREE.PointsMaterial(
      {        
        color: 0x00ff00,
        map: ringTex,
        size: 5.6,
        sizeAttenuation: true,
        transparent: true
      });
         
    let particle = new THREE.Points(portalGeo,portMat);      
    particle.position.set(
      xPos,
      yPos+.1,
      zPos 
      );     
    particle.frustumCulled = false;   
    scene.add(particle);  
    
    let ringPart = new THREE.Points(portalGeo,ringMat);      
    ringPart.position.set(
      xPos,
      yPos+.1,
      zPos 
      );      
    ringPart.frustumCulled = false;   
    scene.add(ringPart);   
}

function BuildPortal(xPos,yPos,endFacing)
{
  gltfLoader.load(
    'assets/portal2.glb',
    (gltf) =>
    {
      const newPortal = gltf.scenes[0].children[0];
      
     
      newPortal.position.x = xPos*10;
      newPortal.position.y = 0;
      newPortal.position.z = (yPos*10)*-1;

      
      /*
      newPortal.position.x = 10;
      newPortal.position.y = 0;
      newPortal.position.z = 0;*/


      newPortal.scale.set(.7,.7,.7);

      //create anchor for portal center
      const centObj = new THREE.Object3D();      
      centObj.position.y = -1;        
      centObj.position.z = -2.5;
      centObj.parent = newPortal;    

      
      switch(endFacing)
      {
        case 14: // south open
        
        break;

        case 13://west open
        newPortal.rotation.z = Math.PI / 2; 
        break;

        case 11:// north open   
        newPortal.rotation.z = Math.PI; 
        break;

        case 7:// east open    
        newPortal.rotation.z = Math.PI / -2; 
        break;
      }

      var centPos = new THREE.Vector3();
      let centQuat = new THREE.Quaternion();      

      centObj.getWorldPosition(centPos);
      const portalShape = new CANNON.Sphere(1);
      const pBody = new CANNON.Body({
      mass: 0,
      position: new CANNON.Vec3(centPos.x,centPos.y,centPos.z),
      shape: portalShape,
      });

      pBody.collisionResponse = 0;
      pBody.addEventListener("collide", function(e){
      console.log(e);
      if (portalUnlocked) {
        WinGame();
      }
      });

      const pLight = new THREE.PointLight( 0x00ff00,1,6);
      pLight.position.set(centPos.x,centPos.y,centPos.z);

      // Store references but DON'T add to scene yet
      portalObject = newPortal;
      portalBody = pBody;
      portalLight = pLight;
      portalPosition = { x: centPos.x, y: centPos.y, z: centPos.z };

      // Don't add to scene or world yet - will be added when portal unlocks
      // scene.add(newPortal);
      // world.addBody(pBody);
      // scene.add(pLight);
      // CreatePortalFX(centPos.x,centPos.y,centPos.z);
      // PortalSoundSpatial(centPos.x,centPos.z);
    }
  );
}


function CalcProbeNeighbor()
{
  neighborCount = 0;

  const nX = Math.floor(curTile/mWidth);
  const nY = (curTile%mWidth);

  /*this isn't preventing curtiles exceeding maze dimensions from being used*/

  //checking east
  if((nX-1)>= 0)
  {    
    if(!Visited.includes(((nX-1)*mWidth)+nY))
    {
      neighborCount += 1;
    }
  }
  //checking north
  if((nY+1)<mLength)
  {    
    if(!Visited.includes((nX*mWidth)+(nY+1)))
    {
      neighborCount += 1;
    }
  }
  //checking west  
  if((nX+1)<mWidth)
  {    
    if(!Visited.includes(((nX+1)*mWidth)+nY))
    {
      neighborCount += 1;
    }
  }
  //checking south
  {
    if((nY-1)>=0)
    {      
      if(!Visited.includes((nX*mWidth)+(nY-1)))
      {
        neighborCount += 1;
      }
    }
  } 
}

function CalcTakeAStep()
{
  const nX = Math.floor(curTile/mWidth);
  const nY = (curTile%mWidth);

  const dir = Math.floor((Math.random() * 4));   

  //cell to the west ---to the left 
  if(dir == 0  && (nX-1)>=0)
  {    
    if(!Visited.includes(((nX-1)*mWidth)+nY))
    {       
      cellArrayNew[curTile].tileTypeId -= 2;// - 2 for west wall on this cell

      curX -=1;
      curTile = (curX*mWidth)+curY;      

      Visited.push(curTile);
      theStack.push(curTile);      
    
      if(cellArrayNew[curTile].ewObj !== null)
      {            
        cellArrayNew[curTile].ewObj = null;           
      }      
      cellArrayNew[curTile].tileTypeId -= 8;// -8 for east wall on west cell  
    }
    return;
  }
  // cell to the north
  if(dir == 1 && (nY +1) < mLength)
  {    
    if(!Visited.includes((nX*mWidth)+(nY+1)))
    {  
      cellArrayNew[curTile].tileTypeId -= 4;    
     
      if(cellArrayNew[curTile].nwObj !== null)
      {                 
        cellArrayNew[curTile].nwObj = null;        
      }     

      curY += 1;
      curTile = (curX*mWidth)+curY;
      cellArrayNew[curTile].tileTypeId -= 1; 
      Visited.push(curTile);
      theStack.push(curTile);  
    }
      return;    
  }
    //cell to the east -- to the right
  if(dir == 2 && (nX +1) < mLength)
  {    
    if(!Visited.includes(((nX+1)*mWidth)+(nY)))
    {
      cellArrayNew[curTile].tileTypeId -= 8;  

      if(cellArrayNew[curTile].ewObj !== null)
      {          
        cellArrayNew[curTile].ewObj = null;         
      }         
      
      curX += 1;
      curTile = (curX*mWidth)+curY;
      cellArrayNew[curTile].tileTypeId -= 2; 
      Visited.push(curTile);
      theStack.push(curTile);   
    }
      return;
  }
    //cell to the south
  if(dir == 3 && (nY-1)>=0)
  { 
    if(!Visited.includes((nX*mWidth)+(nY-1)))
    {
      cellArrayNew[curTile].tileTypeId -= 1;

      curY -= 1;
      curTile = (curX*mWidth)+curY;       

      Visited.push(curTile);
      theStack.push(curTile);
      
      if(cellArrayNew[curTile].nwObj !== null)
      {           
        cellArrayNew[curTile].nwObj = null;         
      }        
      cellArrayNew[curTile].tileTypeId -= 4; 
    }
      return;
  }
}

function CalcPlacePosts(xPos,zPos)
{
   //place posts
   for(let row = 0;row<mWidth+1;row++)
   {
    AddPostInstance(row,)
   }
   // place posts  
}

function CalcBuildEWall(xPos,zPos)
{    
  AddEWallInstance(xPos,zPos,0);

  const body = new CANNON.Body({
    mass: 0,   
    position: new CANNON.Vec3(xPos*10 +5,2.5,(zPos*10)*-1),
    shape: EWshape,    
    });    
    world.addBody(body);
}

function CalcBuildNWall(xPos,zPos)
{  
  AddNWallInstance(xPos,zPos,1);

  const body = new CANNON.Body({
    mass: 0,
    position: new CANNON.Vec3((xPos*10),2.5,((zPos*10)*-1)-5),    
    shape: NWshape,    
    });
    body.quaternion.setFromAxisAngle(new CANNON.Vec3(0,1,0),Math.PI*.5)    
    world.addBody(body); 
}

function PopWalls()
{
  curTile = (curX*mWidth)+curY;   
 
  //this should be block units
  for(let row = 0; row<mWidth; row++)
  {
    for(let column = 0; column<mLength; column++)
    {       
      BuildTile(row,column,cellArrayNew[((row*mWidth)+column)]);      
       
      if(cellArrayNew[((row*mWidth)+column)].ewObj != null)
      {
        CalcBuildEWall(row,column);
      }
      if(cellArrayNew[((row*mWidth)+column)].nwObj != null)
      {
        CalcBuildNWall(row,column); 
      }      
    }   
  }
 


  //place posts 
  for(let row = 0;row<mWidth+1;row++)
  {
    for(let column = 0;column<mLength+1;column++)
    {      
      AddPostInstance(row,column);
    }
  }  
  // place posts  


  //edge walls front
  for(let row = 0;row<mWidth;row++)
  {
    if(row == entX) // this is the entrance
    {
      continue;
    }     
    CalcBuildNWall(row,-1);  
  }


  //left side walls
  for(let column = 0;column<mLength;column++)
  { 
    CalcBuildEWall(-1,column);  
  }
  //edge walls

  // PlaceMazeTraps(); // Removed - no traps in game
  PlaceCollectibles();
  CreatePlayerObj();

  // Audio disabled for LoopMe
  // dayWind.play();  
}


function BuildEntrance()
{
  BuildTileNoMaze(1,-1);
  BuildTileNoMaze(1,-2); 
  
  gltfLoader.load(    
    'assets/sign3.glb',
    (gltf) =>
    {
      const newObj = gltf.scenes[0].children[0];
      /*
      newObj.position.x = 13.6;
      newObj.position.y = 0;
      newObj.position.z = -6;  //4.8
      newObj.scale.set(.5,.5,.5);*/
      
      newObj.position.x = 4.5;
      newObj.position.y = 0;
      newObj.position.z = 9;  //4.8
      newObj.scale.set(1.3,1.3,1.3);  

           
      scene.add(newObj);        
    }
  );

  const shape = new CANNON.Box(new CANNON.Vec3(1,10,10));  
  const body = new CANNON.Body({
  mass: 0,
  position: new CANNON.Vec3(4,0,15),      
  shape: shape,  
  });   
  world.addBody(body); 


  const body2 = new CANNON.Body({
    mass: 0,
    position: new CANNON.Vec3(16,0,15),      
    shape: shape,    
    });    
    world.addBody(body2); 
}




function CheckFurthestPoint()
{
  if(theStack.length > longestDistance)
  {
    furthestPoint = theStack[theStack.length-1];
    longestDistance = theStack.length;
  }
}

function BuildPlatform(xPos,zPos)
{
  const platMat = new THREE.MeshStandardMaterial({
    color: '#4a7c59', // Nice green color for grass
    metalness:0,
    roughness: 0.9
  })
  
  gltfLoader.load(
    'assets/platform.gltf',
    (gltf) =>
    {
      const newObj = gltf.scene.children[0];
      newObj.position.x = xPos;
      newObj.position.y = -.1;
      newObj.position.z = zPos+.1;  
      newObj.scale.set(14,14,14)
      newObj.material = platMat;
      scene.add(newObj);
     
      
      
      const shape = new CANNON.Box(new CANNON.Vec3(5*14,.5,5*14));  
      const body = new CANNON.Body({
      mass: 0,
      position: new CANNON.Vec3(newObj.position.x,newObj.position.y-.5,newObj.position.z),      
      shape: shape,      
      });       
      world.addBody(body);  


      const sideWall = new CANNON.Box(new CANNON.Vec3(5*14,20,3)); 
      const lWall = new CANNON.Body({
      mass: 0,
      position: new CANNON.Vec3(newObj.position.x-73,newObj.position.y,newObj.position.z),     
      shape: sideWall      
      });      

      lWall.quaternion.setFromAxisAngle(new CANNON.Vec3(0,1,0), Math.PI/2)      
      world.addBody(lWall);   

     
      const rWall = new CANNON.Body({
      mass: 0,
      position: new CANNON.Vec3(newObj.position.x+73,newObj.position.y,newObj.position.z),     
      shape: sideWall      
      });      

      rWall.quaternion.setFromAxisAngle(new CANNON.Vec3(0,1,0), Math.PI/2);      
      world.addBody(rWall); 


      const backWall = new CANNON.Body({
      mass: 0,
      position: new CANNON.Vec3(newObj.position.x,newObj.position.y,newObj.position.z+73),     
      shape: sideWall        
      });   
        
      world.addBody(backWall); 
  
      const frontWall = new CANNON.Body({
      mass: 0,
      position: new CANNON.Vec3(newObj.position.x,newObj.position.y,newObj.position.z-73),     
      shape: sideWall         
      });     
          
      world.addBody(frontWall);     
    }
  );
}

function BuildReward()
{
  gltfLoader.load(

    'assets/rIsland.glb',
    (gltf) =>
    {
      const newObj = gltf.scenes[0].children[0];
      newObj.position.x = -50;
      newObj.position.y = 10;
      newObj.position.z = -40;  //4.8
      newObj.scale.set(.1,.1,.1);
      newObj.rotation.z = Math.PI/-6

      // Apply different materials to island (ground) vs chest
      let islandMesh = null;
      let chestMesh = null;

      newObj.traverse((child) => {
        if (child.isMesh) {
          // The chest is typically the smaller object on top
          if (child.position.y > 0 || child.name.includes('Cube')) {
            // This is the chest/reward - make it golden/treasure colored
            child.material = new THREE.MeshStandardMaterial({
              color: '#d4af37', // Gold color
              metalness: 0.8,
              roughness: 0.3,
              emissive: '#ffaa00',
              emissiveIntensity: 0.3
            });
            chestMesh = child;
          } else {
            // This is the island ground - sandy/earthy color
            child.material = new THREE.MeshStandardMaterial({
              color: '#c2b280', // Sandy beige
              metalness: 0,
              roughness: 0.9
            });
            islandMesh = child;
          }
        }
      });

      scene.add(newObj);

      // Add proper 3D trees with trunk and leaves
      const addTree = (x, y, z) => {
        // Tree trunk
        const trunkGeometry = new THREE.CylinderGeometry(0.2, 0.25, 1.5, 8);
        const trunkMaterial = new THREE.MeshStandardMaterial({
          color: '#8b4513', // Brown
          roughness: 0.9
        });
        const trunk = new THREE.Mesh(trunkGeometry, trunkMaterial);
        trunk.position.set(x, y + 0.75, z);
        trunk.castShadow = true;
        scene.add(trunk);

        // Tree leaves (foliage)
        const leavesGeometry = new THREE.SphereGeometry(0.8, 8, 8);
        const leavesMaterial = new THREE.MeshStandardMaterial({
          color: '#228b22', // Forest green
          roughness: 0.8
        });
        const leaves = new THREE.Mesh(leavesGeometry, leavesMaterial);
        leaves.position.set(x, y + 2, z);
        leaves.scale.set(1, 1.2, 1);
        leaves.castShadow = true;
        scene.add(leaves);
      };

      // Add trees around the island edges
      addTree(-54, 8.5, -36);
      addTree(-52, 8.5, -44);
      addTree(-46, 8.5, -38);
      addTree(-55, 8.5, -41);

      // Add colorful bushes/flowers
      const addBush = (x, y, z, color) => {
        const bushGeometry = new THREE.SphereGeometry(0.4, 8, 8);
        const bushMaterial = new THREE.MeshStandardMaterial({
          color: color,
          emissive: color,
          emissiveIntensity: 0.3,
          roughness: 0.7
        });
        const bush = new THREE.Mesh(bushGeometry, bushMaterial);
        bush.position.set(x, y, z);
        bush.scale.set(1, 0.7, 1);
        scene.add(bush);
      };

      // Add colorful flowering bushes
      addBush(-51, 8.5, -37, '#ff69b4'); // Pink flowers
      addBush(-49, 8.5, -42, '#9370db'); // Purple flowers
      addBush(-53, 8.5, -39, '#ffa500'); // Orange flowers
      addBush(-48, 8.5, -40, '#ff1493'); // Deep pink

      // Load the product hologram above the chest (billboard sprite)
      const productTexture = textureLoader.load('assets/horlicks-product.webp');
      const spriteMaterial = new THREE.SpriteMaterial({
        map: productTexture,
        transparent: true,
        opacity: 0.9,
        color: new THREE.Color('#ffffff')
      });

      const productSprite = new THREE.Sprite(spriteMaterial);
      productSprite.position.set(-49, 16, -40.6);
      productSprite.scale.set(8, 8, 1);
      productSprite.visible = false;
      scene.add(productSprite);
      window.productHologram = productSprite;

      // Add hologram glow effect
      const glowGeometry = new THREE.SphereGeometry(2, 16, 16);
      const glowMaterial = new THREE.MeshBasicMaterial({
        color: '#00ffff',
        transparent: true,
        opacity: 0.2,
        side: THREE.BackSide
      });
      const glowSphere = new THREE.Mesh(glowGeometry, glowMaterial);
      glowSphere.position.copy(productSprite.position);
      glowSphere.visible = false;
      scene.add(glowSphere);
      window.hologramGlow = glowSphere;

      const podShape = new CANNON.Box(new CANNON.Vec3(1,3,1));  
      const podBody = new CANNON.Body({
      mass: 0,      
      position: new CANNON.Vec3(newObj.position.x+1,newObj.position.y+2,newObj.position.z-.6),      
      shape: podShape,      
      });     
      world.addBody(podBody); 
     
      const islShape = new CANNON.Box(new CANNON.Vec3(5.5,2.5,6.6));  
      const body = new CANNON.Body({
      mass: 0,      
      position: new CANNON.Vec3(newObj.position.x-.5,newObj.position.y -2.5,newObj.position.z),      
      shape: islShape      
      });
      body.quaternion.setFromAxisAngle(new CANNON.Vec3(0,1,0), newObj.rotation.z);      
      world.addBody(body);      
      const islBarWall = new CANNON.Box(new CANNON.Vec3(2,6,8));
           
      const b1 = new CANNON.Body({
      mass: 0,      
      position: new CANNON.Vec3(newObj.position.x+5.8,newObj.position.y+2,newObj.position.z+3.5),
      shape: islBarWall,      
      });
      b1.quaternion.setFromAxisAngle(new CANNON.Vec3(0,1,0), newObj.rotation.z)      
      world.addBody(b1);
          
      const b2 = new CANNON.Body({
      mass: 0,        
      position: new CANNON.Vec3(newObj.position.x-5.8,newObj.position.y+2,newObj.position.z-5.6),
      shape: islBarWall,      
      });
      b2.quaternion.setFromAxisAngle(new CANNON.Vec3(0,1,0), newObj.rotation.z)        
      world.addBody(b2);
    
      const c1 = new CANNON.Body({
      mass: 0,        
      position: new CANNON.Vec3(newObj.position.x,newObj.position.y+2,newObj.position.z-7),
      shape: islBarWall,      
      });
      c1.quaternion.setFromAxisAngle(new CANNON.Vec3(0,1,0), newObj.rotation.z+ Math.PI/-3.5 ) //Math.PI/-2.3       
      world.addBody(c1); 
        
      const c2 = new CANNON.Body({
      mass: 0,        
      position: new CANNON.Vec3(newObj.position.x+7,newObj.position.y+2,newObj.position.z-5), 
      shape: islBarWall,      
      });
      c2.quaternion.setFromAxisAngle(new CANNON.Vec3(0,1,0),newObj.rotation.z+Math.PI/3.5)        
      world.addBody(c2);
         
      const c3 = new CANNON.Body({
      mass: 0,        
      position: new CANNON.Vec3(newObj.position.x-6,newObj.position.y+2,newObj.position.z+8),
      shape: islBarWall,      
      });
      c3.quaternion.setFromAxisAngle(new CANNON.Vec3(0,1,0),newObj.rotation.z+ Math.PI/3.7)        
      world.addBody(c3);      
        
      const c4 = new CANNON.Body({
      mass: 0,        
      position: new CANNON.Vec3(newObj.position.x-2,newObj.position.y+2,newObj.position.z+8),
      shape: islBarWall,      
      });
      c4.quaternion.setFromAxisAngle(new CANNON.Vec3(0,1,0), newObj.rotation.z + Math.PI/-3.7)
      world.addBody(c4);
    }
  );
}

function CreateCollectibleVisual(type, isGreen) {
  const group = new THREE.Group();
  let lightColor = isGreen ? 0x00ffcc : 0xff6633;

  const addMesh = (geom, color, metalness = 0.1, roughness = 0.4) => {
    const mesh = new THREE.Mesh(
      geom,
      new THREE.MeshStandardMaterial({
        color,
        metalness,
        roughness,
        emissive: new THREE.Color(color).multiplyScalar(0.1)
      })
    );
    mesh.castShadow = true;
    mesh.receiveShadow = true;
    group.add(mesh);
    return mesh;
  };

  switch (type) {
    case 'almond': {
      if (!almondReady || !almondModel) {
        return { mesh: null, lightColor };
      }
      const clone = almondModel.clone(true);
      clone.traverse((child) => {
        if (child.isMesh) {
          child.castShadow = true;
          child.receiveShadow = true;
        }
      });
      clone.position.set(0, 0, 0);
      clone.rotation.set(0, 0, 0);
      clone.scale.copy(almondModel.scale);
      clone.updateMatrixWorld(true);
      group.add(clone);
      lightColor = 0xffcfa3;
      break;
    }
    case 'millet': {
      lightColor = 0xffe8a6;
      const offsets = [
        [0, 0.2, 0],
        [0.35, -0.05, 0.1],
        [-0.35, -0.05, -0.1],
        [0.1, -0.25, -0.3]
      ];
      offsets.forEach(([x, y, z]) => {
        const s = 0.32 + Math.random() * 0.08;
        const mesh = addMesh(new THREE.SphereGeometry(s, 14, 14), 0xe5d07c, 0, 0.55);
        mesh.position.set(x, y, z);
      });
      break;
    }
    case 'oats': {
      lightColor = isGreen ? 0xb7b79a : lightColor;
      const body = addMesh(new THREE.CylinderGeometry(0.3, 0.32, 1.15, 14), 0xd9c39f, 0.05, 0.45);
      body.rotation.z = Math.PI / 6;
      body.rotation.x = Math.PI / 12;
      break;
    }
    case 'fries': {
      lightColor = 0xffd36a;
      const container = addMesh(new THREE.BoxGeometry(1.1, 0.45, 0.9), 0xc00025, 0.3, 0.35);
      container.position.y = -0.35;
      const fryOffsets = [-0.4, -0.1, 0.2, 0.45];
      fryOffsets.forEach((x, idx) => {
        const fry = addMesh(new THREE.BoxGeometry(0.22, 1.05 + idx * 0.12, 0.22), 0xffc94a, 0.05, 0.5);
        fry.position.set(x, 0.1 + idx * 0.05, (idx % 2 === 0 ? -0.1 : 0.15));
        fry.rotation.z = (idx - 1.5) * 0.15;
      });
      break;
    }
    case 'cola':
    default: {
      lightColor = 0xff5555;
      const drink = addMesh(new THREE.CylinderGeometry(0.45, 0.5, 1.15, 18), 0x5b0f0f, 0.25, 0.4);
      drink.position.y = 0.05;
      const rim = addMesh(new THREE.TorusGeometry(0.45, 0.05, 10, 24), 0xa0d8f1, 0.1, 0.25);
      rim.rotation.x = Math.PI / 2;
      rim.position.y = 0.6;
      break;
    }
  }

  return { mesh: group, lightColor };
}

function centerOnGround(mesh) {
  const box = new THREE.Box3().setFromObject(mesh);
  const size = new THREE.Vector3();
  box.getSize(size);
  const center = new THREE.Vector3();
  box.getCenter(center);
  mesh.position.sub(center);
  const adjustedBox = new THREE.Box3().setFromObject(mesh);
  mesh.position.y -= adjustedBox.min.y;
  const finalBox = new THREE.Box3().setFromObject(mesh);
  const height = finalBox.max.y - finalBox.min.y;
  const radius = Math.max(height, finalBox.max.x - finalBox.min.x, finalBox.max.z - finalBox.min.z) * 0.75 + 0.25;
  return { box: finalBox, height, radius: Math.max(radius, 0.9) };
}

function spawnPendingCollectibles() {
  if (!pendingCollectibles.length) return;
  const toSpawn = pendingCollectibles.splice(0, pendingCollectibles.length);
  toSpawn.forEach((cfg) => {
    SpawnCollectible(cfg.x, cfg.z, cfg.category, cfg.type);
  });
}

function SpawnCollectible(xPos, zPos, category, type) {
  // Delay almond until its GLB is loaded
  if (type === 'almond' && !almondReady) {
    pendingCollectibles.push({ x: xPos, z: zPos, category, type });
    return null;
  }

  const { mesh, lightColor } = CreateCollectibleVisual(type, category === 'wholesome');
  if (!mesh) {
    return null;
  }

  const { height, radius } = centerOnGround(mesh);
  mesh.position.set(xPos, mesh.position.y, zPos);
  mesh.frustumCulled = false;
  scene.add(mesh);

  const collectLight = new THREE.PointLight(lightColor, 0.8, 6);
  collectLight.position.set(xPos, mesh.position.y + height * 0.65, zPos);
  scene.add(collectLight);

  const collectBody = new CANNON.Body({
    mass: 0,
    position: new CANNON.Vec3(xPos, mesh.position.y + height * 0.5, zPos),
    shape: new CANNON.Sphere(radius),
  });
  collectBody.collisionResponse = 0;
  world.addBody(collectBody);

  const collectibleObj = {
    mesh,
    light: collectLight,
    body: collectBody,
    category,
    type,
    collected: false,
    x: xPos,
    z: zPos
  };

  collectBody.addEventListener("collide", function() {
    HandleCollectibleCollision(collectibleObj);
  });

  if (category === 'wholesome') {
    wholesomeCollectibles.push(collectibleObj);
  } else {
    hazardCollectibles.push(collectibleObj);
  }

  return collectibleObj;
}

function HandleCollectibleCollision(collectibleObj) {
  if (collectibleObj.collected) return;

  collectibleObj.collected = true;
  scene.remove(collectibleObj.mesh);
  scene.remove(collectibleObj.light);
  world.remove(collectibleObj.body);

  if (collectibleObj.category === 'wholesome') {
    wholesomeCollected++;
    UpdateGreenLightsDisplay();

    // LoopMe: Check if we should unlock portal (respects COLLECTIBLES_REQUIRED)
    if (wholesomeCollected >= COLLECTIBLES_REQUIRED && !portalUnlocked) {
      UnlockPortal();
    }
  } else {
    LoseLife();
  }
}

function UpdateGreenLightsDisplay() {
  const display = document.querySelector('#greenLightsDisplay');
  const targetElement = document.querySelector('#collectiblesTarget');
  if (display) {
    display.textContent = wholesomeCollected + ' / ' + COLLECTIBLES_REQUIRED;
  }
  if (targetElement) {
    targetElement.textContent = COLLECTIBLES_REQUIRED;
  }
}

function UnlockPortal() {
  if (portalUnlocked || !portalObject) return;

  portalUnlocked = true;

  scene.add(portalObject);
  world.addBody(portalBody);
  scene.add(portalLight);

  CreatePortalFX(portalPosition.x, portalPosition.y, portalPosition.z);
  // PortalSoundSpatial(portalPosition.x, portalPosition.z); // Audio disabled for LoopMe
  ShowPortalUnlockedMessage();
  CreatePortalArrow();
}

function WinGame() {
  // Don't disable player controls - keep playerLoaded = true
  ShowWinScreen();
  setTimeout(() => {
    HideWinScreen();
    SendToIsland();
  }, 3000); // Show win screen for 3 seconds, then hide and teleport
}

function ShowPortalUnlockedMessage() {
  const message = document.querySelector('#portalMessage');
  if (message) {
    message.style.display = 'block';
    gsap.fromTo(message,
      { opacity: 0, scale: 0.5 },
      { opacity: 1, scale: 1, duration: 0.5 }
    );
    setTimeout(() => {
      gsap.to(message, { opacity: 0, duration: 0.5 });
    }, 3000);
  }
}



// BuildTrap function commented out - FBX loader and wallTrapAnim4.fbx removed for size optimization
/*
function BuildTrap(xPos,zPos,hRot)
{
  fbxLoader.load(
    'assets/wallTrapAnim4.fbx',
    (object)=>
    {
      object.children[0].material = wallMat;
      object.children[1].material = wallMat;
      object.position.x = xPos;
      object.position.y = 2.6;
      object.position.z = zPos;
      if(hRot == 1)
      {
        object.rotation.y = Math.PI / 2;
      }
      scene.add(object);

      let trapObj = {
        x: xPos,
        z: zPos,
        trap: null,
        animClip: null,
        col1: null,
        col2: null,
        timeOutId: null
      };

    mixer = new THREE.AnimationMixer(object);
    aniMixers.push(mixer);
    animTest = mixer.clipAction(object.animations[0]);

    animTest.setLoop(THREE.LoopOnce);
    animTest.clampWhenFinished = true;
    animTest.enable = true;

    trapObj.animClip = animTest;

    const body = new CANNON.Body({
      mass: 0,
      position: new CANNON.Vec3(object.children[1].position.x,object.children[1].position.y,object.children[1].position.z),
      shape: clapTrapShape
    });
    body.collisionResponse = 0;
    body.addEventListener("collide", function(e){
       console.log(e);
       LoseLife();
      });
    world.addBody(body);



    trapsToUpdate.push({
      mesh: object.children[1],
      body: body
    });

    const body2 = new CANNON.Body({
      mass: 0,
      position: new CANNON.Vec3(object.children[0].position.x,object.children[0].position.y,object.children[0].position.z),
      shape: clapTrapShape
    });
    body2.collisionResponse = 0;
    body2.addEventListener("collide", function(e){
      console.log(e);
      LoseLife();
     });
    world.addBody(body2);


    trapsToUpdate.push({
      mesh: object.children[0],
      body: body2
    });

    trapObj.trap = object;
    trapObj.col1 = body;
    trapObj.col2 = body2;
    trapArr.push(trapObj);


    // can start the animation here
    animTest.reset();
    animTest.play();
    const inter = (Math.floor((Math.random() * 6))+2)*1000;
    setTimeout(function() { FireTrap(trapObj)}, inter);
    }
  );
}
*/



// FireTrap function commented out - only used by BuildTrap which is removed
/*
function FireTrap(objAnim)
{  if(trapsOut)
  {
  objAnim.animClip.reset();
  objAnim.animClip.play();
  // TrapSoundSpatial(objAnim.x,objAnim.z); // Audio disabled for LoopMe
  const inter = (Math.floor((Math.random() * 6))+2)*1000;
  objAnim.timeOutId = setTimeout(function() { FireTrap(objAnim)}, inter);
  }
}
*/
  
function FireTraps()
{
  for(const ani of trapArr)
  {
    ani.animClip.reset();      
    ani.animClip.play();
    const inter = (Math.floor((Math.random() * 4))+1)*1000;
    setTimeout(function() { FireTrap(ani)}, inter);
  } 
}


function CancelTraps()
{
  trapsOut =  false;
  for(const ani of trapArr)
  {
    scene.remove(ani.trap);
    world.remove(ani.col1);
    world.remove(ani.col2);
    clearTimeout(ani.timeOutId);
    ani.timeOutId = null;
  }
}

function UnCancelTraps()
{  
  trapsOut =  true;
  for(const ani of trapArr)
  {
    scene.add(ani.trap);
    world.add(ani.col1);
    world.add(ani.col2);
    FireTrap(ani);
  }    
}

function PlaceMazeTraps()
{
  trapsOut = true;
  // trapTogg.click(); // Removed - trap toggle element no longer exists
  for(let row = 0;row<mWidth;row++)
  {
    for(let column = 0;column<mLength;column++)
    {
      const tileNum = (row*mWidth)+column;      

      if(cellArrayNew[tileNum].tileTypeId == 10 || cellArrayNew[tileNum].tileTypeId == 5)// if north south or east west hall
      {
        const randChance = Math.floor((Math.random() * 10));

        if(randChance>7)
        {
          if(cellArrayNew[tileNum].tileTypeId == 5)
          {
            // BuildTrap(row*mWidth,(column*10)*-1,0); // Commented - FBX loader removed
          }
          if(cellArrayNew[tileNum].tileTypeId == 10)
          {
            // BuildTrap(row*mWidth,(column*10)*-1,1); // Commented - FBX loader removed
          }
        }
      }
    }
  }

}

function ClearCollectibles() {
  const all = [...wholesomeCollectibles, ...hazardCollectibles];
  all.forEach((c) => {
    if (c.mesh) scene.remove(c.mesh);
    if (c.light) scene.remove(c.light);
    if (c.body) world.removeBody(c.body);
  });
  wholesomeCollectibles.length = 0;
  hazardCollectibles.length = 0;
  pendingCollectibles.length = 0;
}

function PlaceCollectibles() {
  ClearCollectibles();
  wholesomeCollected = 0;
  UpdateGreenLightsDisplay();

  const validTiles = [];

  for (let row = 0; row < mWidth; row++) {
    for (let column = 0; column < mLength; column++) {
      if (row === entX && column === entY) continue;
      const tileIndex = row * mWidth + column;
      if (tileIndex === furthestPoint) continue;

      validTiles.push({ x: row, z: column });
    }
  }

  // Shuffle tiles
  for (let i = validTiles.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [validTiles[i], validTiles[j]] = [validTiles[j], validTiles[i]];
  }

  const wholesomeTypes = collectibleConfig.wholesomeTypes;
  const hazardTypes = collectibleConfig.hazardTypes;

  // Place wholesome pickups (almond/millet/oats)
  for (let i = 0; i < collectibleConfig.wholesomeTarget && i < validTiles.length; i++) {
    const tile = validTiles[i];
    const type = wholesomeTypes[i % wholesomeTypes.length];
    SpawnCollectible(tile.x * 10, (tile.z * 10) * -1, 'wholesome', type);
  }

  // Place hazards (fries/cola)
  const hazardStart = collectibleConfig.wholesomeTarget;
  const hazardLimit = Math.min(validTiles.length, hazardStart + collectibleConfig.hazardCount);
  for (let i = hazardStart; i < hazardLimit; i++) {
    const tile = validTiles[i];
    const type = hazardTypes[(i - hazardStart) % hazardTypes.length];
    SpawnCollectible(tile.x * 10, (tile.z * 10) * -1, 'hazard', type);
  }
}

//#endregion Build out


//#region Player Object

let playerLoaded = false;

function CreatePlayerObj()
{
  // main player model with idle
  gltfLoader.load(
    'assets/Skele/idle_1_male_free_animation_200_frames_loop.glb',
    (gltf) =>
    {
      playerObj = gltf.scene;

      // Normalize size and place on ground
      const box = new THREE.Box3().setFromObject(playerObj);
      const size = new THREE.Vector3();
      box.getSize(size);
      const height = Math.max(size.y, 0.001);
      const targetHeight = 0.7; // Reduced from 2.2 to make character smaller
      const scale = targetHeight / height;
      playerObj.scale.setScalar(scale);

      const center = new THREE.Vector3();
      box.getCenter(center);
      playerObj.position.sub(center);
      const adjusted = new THREE.Box3().setFromObject(playerObj);
      playerObj.position.y -= adjusted.min.y;

      playerObj.position.x = 10;
      playerObj.position.y += 0; // already grounded
      playerObj.position.z = 20;  
      playerObj.rotation.y = Math.PI;

      playerObj.traverse( ( object ) => {
          object.frustumCulled = false;  
          if (object.isMesh) {
            object.castShadow = true;
            object.receiveShadow = true;
          }
        } 
      );      

      RemoveHorns(playerObj);

      skeleMixer = new THREE.AnimationMixer(playerObj);
      aniMixers.push(skeleMixer);

      loadAnimationClip(idleAnimPath, (clip) => {
        if (clip) {
          idleAction = skeleMixer.clipAction(clip);
          idleAction.setLoop(THREE.LoopRepeat);
          idleAction.enable = true;
          skeleAnimArr.push(idleAction);
        }
        checkPlayerReady();
      });

      loadAnimationClip(runAnimPath, (clip) => {
        if (clip) {
          runAction = skeleMixer.clipAction(clip);
          runAction.setLoop(THREE.LoopRepeat);
          runAction.enable = true;
        }
        checkPlayerReady();
      });
      scene.add(playerObj)
    
    
      const charShape = new CANNON.Sphere(1);   
      charBody = new CANNON.Body({
      mass: 1,    
      position: new CANNON.Vec3(0,0,0),
      shape: charShape      
      });
  
      charBody.fixedRotation = true;
      charBody.angularDamping = 1;
      
      charBody.position.set(10,1,20);  //(10,1,20)   //island -54,11,-38.5
      world.addBody(charBody);  
    
      objectsToUpdate.push({       
      mesh: playerObj,
      body: charBody
      });

      camSpot = new THREE.Mesh(
      new THREE.SphereBufferGeometry(.2,4,4),
      wallMat);
      camSpot.castShadow = true;     
      camSpot.position.x = 0;
      camSpot.position.y = 4;//5.7    
      camSpot.position.z = -5;//5
      camSpot.rotation.y -= Math.PI;
      camSpot.rotateX((Math.PI/180)*-20);//-25
      camSpot.visible = false;
      scene.add(camSpot);      
      camSpot.parent = playerObj;

      // Initialize UI
      UpdateLivesDisplay();
      UpdateGreenLightsDisplay();

      SetEnv(startEnv);    
    //// swing the camera down in and begin game when this loads      
    }
  );
}

function RemoveHorns(root) {
  if (!root) return;
  root.traverse((child) => {
    if (!child.name) return;
    const nm = child.name.toLowerCase();
    if (nm.includes('horn')) {
      child.visible = false;
      if (child.isBone) {
        child.scale.set(0.0001, 0.0001, 0.0001);
      }
    }
  });
}

function loadAnimationClip(path, onSuccess) {
  gltfLoader.load(
    path,
    (gltf) => {
      if (gltf.animations && gltf.animations.length) {
        onSuccess(gltf.animations[0]);
      } else {
        console.warn('No animations in', path);
        onSuccess(null);
      }
    },
    undefined,
    (err) => {
      console.warn('Failed to load animation', path, err);
      onSuccess(null);
    }
  );
}

function checkPlayerReady() {
  if (playerLoaded) return;
  if (idleAction) {
    if (!runAction) {
      runAction = idleAction;
    }
    playerLoaded = true;
    ChangeAnimation(0);
  }
}

//#endregion Player Object


  
function SendToIsland()
{
  charBody.position.x = -52;
  charBody.position.y = 11;
  charBody.position.z = -35;

  // Set island flag for hologram click detection
  onIsland = true;

  // Show the island CTA message
  ShowIslandMessage();
}

function ShowIslandMessage() {
  const message = document.querySelector('#islandMessage');
  if (message) {
    message.style.display = 'block';
    gsap.fromTo(message,
      { opacity: 0, scale: 0.8 },
      { opacity: 1, scale: 1, duration: 0.8 }
    );
  }
}

function HideIslandMessage() {
  const message = document.querySelector('#islandMessage');
  if (message) {
    gsap.to(message, {
      opacity: 0,
      duration: 0.5,
      onComplete: () => {
        message.style.display = 'none';
      }
    });
  }
}





BuildPlatform(45,-45);
BuildReward();
BuildEntrance();


//auto build
LoadAll();




/*
document.addEventListener('keydown', function(e){
  if(e.key === '1')
  {
    //LoadAll();
    //scene.background = bgTexture;    
  }  
});

document.addEventListener('keydown', function(e){
  if(e.key === '2')
  {
    //LoadAll();
    //CancelTraps();
    //scene.background = bgTexture2;
    //console.log("calling 2")    
    // console.log(Howler); // Audio disabled for LoopMe
  }  
});

document.addEventListener('keydown', function(e){
  if(e.key === '3')
  {
    //UnCancelTraps();
    //scene.background =duskTexture;
    playerObj.children[0].children[1].material.map = playerBlue3;
  }  
});
*/









//setTimeout(function() {CarveMaze()}, 5000);

 
/*
document.addEventListener('keydown', function(e){
      if(e.key === 'q')
      {    
        LoadAll();   
      }  
    });
*/


  
document.addEventListener('keydown', function(e){
    if(e.key === 't')
    {    
      console.log(renderer.info);
      //console.log(charBody.position);
    }  
  });
  

  

//#region Player controls
let maxSpeed = .3,minSpeed = -.2,speed = 0,acceler = .2,turnAccel = 4,angle = 0;

let moving = 0,turning = 0;


//arow keys
document.onkeydown = (event) =>
{
  if(!playerLoaded)
  {
    return;
  }

  // LoopMe: Track first interaction
  trackFirstInteraction();

  switch(event.key)
  {
    case "a":
      turning = -1;
    break;
    case "d":
      turning = 1;
    break;
    case "w":
      moving = 1;
      ChangeAnimation(1);
    break;
    case "s":
      moving = -1;
      ChangeAnimation(2);
    break;
  }
}

document.onkeyup = (event) => 
{
  if(!playerLoaded)
  {    
    return;
  }
  switch(event.key)
  {    
    case "a":    
    turning = 0;
    break;
    case "d":        
      turning = 0;
    break;
    case "w":        
      speed = 0;
      moving = 0;        
      ChangeAnimation(0);    
    break;
    case "s":        
      speed = 0;
      moving = 0; 
      ChangeAnimation(0);     
    break;
  }
}
//#endregion Player controls




//#region UI
////UI===========================================================================
////=============================================================================



// Settings menu removed - commenting out gear button and options bar
// const optButton = document.querySelector('.menu__gear');
// const optionsBar = document.querySelector('.menu__main');

// let gearsOpen = false;

// optButton.addEventListener('click', function (event) {
//   if(!gearsOpen) {
//     gearsOpen = true;
//     gsap.to(optButton, {rotation: 540, duration: 1});
//     gsap.to(this, 0.4, {scale:1.3, ease:Bounce.easeOut});
//     gsap.to(this, 0.2, {scale:1, delay:0.4})
//     unfurlBar();
//   }
//   else {
//     gearsOpen = false;
//     gsap.to(optButton, {rotation: 0, duration: 1});
//     gsap.to(this, 0.4, {scale:.8, ease:Bounce.easeOut});
//     gsap.to(this, 0.2, {scale:1, delay:0.4})
//     refurlBar();
//   }
// });

// Settings menu removed - commenting out unfurl/refurl functions
// function unfurlBar(){
//   let amt = window.innerWidth *.8;
//
//   if(window.innerWidth>window.innerHeight)
//   {
//     amt = window.innerWidth *.2;
//   }
//   gsap.to(optionsBar, {y: amt, duration: 1});
// }
//
// function refurlBar(){
//   gsap.to(optionsBar, {y: 0, duration: 1});
// }

// Settings menu removed - commenting out closeMenu function
// function closeMenu(){
//   gearsOpen = false;
//   gsap.to(optButton, {rotation: 0, duration: 1});
//   gsap.to(optButton, 0.4, {scale:.8, ease:Bounce.easeOut});
//   gsap.to(optButton, 0.2, {scale:1, delay:0.4})
//   refurlBar();
// }

const reloadBut = document.querySelector('.reloadButton');


reloadBut.addEventListener('click', function (event) {  
gsap.to(this, 0.1, {scale:.8});
  gsap.to(this, 0.1, {scale:1, delay:0.1})
  setTimeout(function() {window.location.reload()}, 200);  
});





// menu buttons
// Settings menu removed - commenting out character color selectors
// const lCCChev = document.querySelector('#ccCL');
// const rCCChev = document.querySelector('#ccCR');
// const lCCBut = document.querySelector('#ccL');
// const rCCBut = document.querySelector('#ccR');
// const DccBut = document.querySelector('#ccDisp');

// rCCBut.addEventListener('click', function (event) {
//   gsap.to(this, 0.1, {scale:.8});
//   gsap.to(this, 0.1, {scale:1, delay:0.1});
//   SwapPlayerTex(1);
// });

// lCCBut.addEventListener('click', function (event) {
//   gsap.to(this, 0.1, {scale:.8});
//   gsap.to(this, 0.1, {scale:1, delay:0.1});
//   SwapPlayerTex(-1);
// });

// lCCBut.style.display = "none";

// Settings menu removed - commenting out SwapPlayerTex function (character is always blue now)
// function SwapPlayerTex(inc)
// {
//   pCurTexNum += inc;
//   if(pCurTexNum>2)
//   {
//     pCurTexNum = 0;
//   }
//   if(pCurTexNum<0)
//   {
//     pCurTexNum = 2;
//   }
//
//   switch(pCurTexNum)
//   {
//     case 0:
//     DccBut.innerHTML = "Red"
//     playerObj.children[0].children[1].material.map = playerRed;
//     lCCBut.style.display = "none";
//     rCCBut.style.display = "Block";
//     break;
//
//     case 1:
//     DccBut.innerHTML = "Green"
//     playerObj.children[0].children[1].material.map = playerGreen;
//     lCCBut.style.display = "block";
//     rCCBut.style.display = "Block";
//     break;
//
//     case 2:
//     DccBut.innerHTML = "Blue"
//     playerObj.children[0].children[1].material.map = playerBlue;
//     lCCBut.style.display = "block";
//     rCCBut.style.display = "none";
//     break;
//   }
// }


// Settings menu removed - commenting out environment selectors
// const lEnvChev = document.querySelector('#envCL');
// const rEnvChev = document.querySelector('#envCR');
// const lEnvBut = document.querySelector('#envL');
// const rEnvBut = document.querySelector('#envR');
// const dEnvBut = document.querySelector('#envDisp');

// lEnvBut.addEventListener('click', function (event) {
//   gsap.to(this, 0.1, {scale:.8});
//   gsap.to(this, 0.1, {scale:1, delay:0.1});
//   SwapEnvTex(-1);
// });

// rEnvBut.addEventListener('click', function (event) {
//   gsap.to(this, 0.1, {scale:.8});
//   gsap.to(this, 0.1, {scale:1, delay:0.1});
//   SwapEnvTex(1);
// });

// lEnvBut.style.display = "none";


// Simple environment setter to keep calls safe (always day for now)
function SetEnv() {
  // No HDR environment - using basic lighting only
  scene.environment = null;
  scene.background = bgTexture;
}




// Settings menu removed - commenting out SwapEnvTex function (environment is always day now)
// function SwapEnvTex(inc)
// {
//   envTexNum += inc;
//   if(envTexNum>2)
//   {
//     envTexNum = 0;
//   }
//   if(envTexNum<0)
//   {
//     envTexNum = 2;
//   }
//
//   switch(envTexNum)
//   {
//     case 0:
//     dEnvBut.innerHTML = "Day"
//     scene.environment = dayEnvTex;
//     scene.background =bgTexture;
//     playerObj.children[0].children[1].material.envMapIntensity = 6;
//     playerObj.children[0].children[2].material.envMapIntensity = 6;
//     lEnvBut.style.display = "none";
//     rEnvBut.style.display = "Block";
//     dayWind.play();
//     crickets.stop();
//     chimes.stop();
//     break;
//
//     case 1:
//     dEnvBut.innerHTML = "Dusk"
//     scene.environment = duskEnvTex;
//     scene.background = duskTexture;
//     playerObj.children[0].children[1].material.envMapIntensity = 6;
//     playerObj.children[0].children[2].material.envMapIntensity = 6;
//     lEnvBut.style.display = "block";
//     rEnvBut.style.display = "Block";
//     chimes.play();
//     dayWind.stop();
//     crickets.stop();
//     break;
//
//     case 2:
//     dEnvBut.innerHTML = "Night"
//     scene.environment = nightEnvTex;
//     scene.background =night3Texture;
//     playerObj.children[0].children[1].material.envMapIntensity = 15;
//     playerObj.children[0].children[2].material.envMapIntensity = 15;
//     lEnvBut.style.display = "block";
//     rEnvBut.style.display = "none";
//     crickets.play();
//     dayWind.stop();
//     chimes.stop()
//     break;
//   }
// }




// Settings menu removed - commenting out volume slider
// var volSlider = document.getElementById("myRange");
// volSlider.oninput = function() {
//   Howler.volume(this.value/100);
// }


// const trapTogg = document.querySelector('#trapTog'); // Removed - element no longer exists
// trapTogg.addEventListener('change', (e) => {
//   this.checkboxValue = e.target.checked ? UnCancelTraps() : CancelTraps();
// })


// menu buttons








////touch controls===========================================================
const leftButton = document.querySelector('#lB');
const upButton = document.querySelector('#uB');
const downButton = document.querySelector('#dB');
const rightButton = document.querySelector('#rB');

//touchstart  //mousedown
leftButton.addEventListener('touchstart', function (event) {
  event.preventDefault();
  if(!playerLoaded)
  {
    return;
  }
  trackFirstInteraction(); // LoopMe tracking
  turning = -1;
  leftButton.classList.add("--leftImgTouched");
});
upButton.addEventListener('touchstart', function (event) {
  event.preventDefault();
  if(!playerLoaded)
  {
    return;
  }
  trackFirstInteraction(); // LoopMe tracking
  moving = 1;
  ChangeAnimation(1);
  upButton.classList.add("--upImgTouched");
});
downButton.addEventListener('touchstart', function (event) {
  event.preventDefault();
  if(!playerLoaded)
  {
    return;
  }
  trackFirstInteraction(); // LoopMe tracking
  moving = -1;
  ChangeAnimation(2);
  downButton.classList.add("--downImgTouched");
});
rightButton.addEventListener('touchstart', function (event) {
 event.preventDefault();
 if(!playerLoaded)
  {
    return;
  }
  trackFirstInteraction(); // LoopMe tracking
  turning = 1; 
  rightButton.classList.add("--rightImgTouched");  
});


//touchend  //mouseup
leftButton.addEventListener('touchend', function (event) {
  event.preventDefault();
  if(!playerLoaded)
  {    
    return;
  }
  turning = 0;  
  leftButton.classList.remove("--leftImgTouched");
});
upButton.addEventListener('touchend', function (event) {
  event.preventDefault(); 
  if(!playerLoaded)
  {    
    return;
  }
  speed = 0;
  moving = 0;        
  ChangeAnimation(0);  
  upButton.classList.remove("--upImgTouched");
});
downButton.addEventListener('touchend', function (event) {
  event.preventDefault();
  if(!playerLoaded)
  {    
    return;
  }
  speed = 0;
  moving = 0;        
  ChangeAnimation(0);   
  downButton.classList.remove("--downImgTouched");
});
rightButton.addEventListener('touchend', function (event) {
  event.preventDefault();  
  if(!playerLoaded)
  {    
    return;
  }
  turning = 0;  
  rightButton.classList.remove("--rightImgTouched");
});
////touch controls===========================================================






////UI===========================================================================
////=============================================================================
//#endregion UI





function ChangeAnimation(num)
{  
  if(curAction == num)
  {
    return;
  } 

  curAction = num;

  switch(num)
  {    
    case 0:    //go to idle     
    if(currentAction)
    {
      currentAction.fadeOut(.3);
    }
    // footSteps.fade(1,0,300); // Audio disabled for LoopMe
    idleAction.reset();
    idleAction.fadeIn(.3);
    idleAction.play();
    currentAction = idleAction;
    break;
  
    case 1:  // go to run
    if(currentAction)
    {
      currentAction.fadeOut(.3);
    }
    // footSteps.stop(); // Audio disabled for LoopMe
    // footSteps.rate(1);
    // footSteps.volume(.3);
    // footSteps.play(); // Audio disabled for LoopMe

    runAction.timeScale = 2;
    runAction.reset();    
    runAction.play();
    currentAction = runAction;    
    break;

    case 2:    // run backwards 
    if(currentAction)
    {
      currentAction.fadeOut(.3);
    }

    // footSteps.stop(); // Audio disabled for LoopMe
    // footSteps.rate(.66);
    // footSteps.volume(.3);
    // footSteps.play(); // Audio disabled for LoopMe

    runAction.reset();
    runAction.timeScale = -1.33;
    runAction.play();
    currentAction = runAction;
    break;
  }

}

function LoseLife() {
  if (isInvulnerable || playerLives <= 0) return;

  playerLives--;
  UpdateLivesDisplay();

  if (playerLives <= 0) {
    GameOver();
    return;
  }

  // Grant brief invulnerability
  isInvulnerable = true;
  FlashPlayer();
  setTimeout(() => { isInvulnerable = false; }, invulnerabilityDuration);
}

function FlashPlayer() {
  let flashCount = 0;
  const flashInterval = setInterval(() => {
    if (playerObj && playerObj.children[0] && playerObj.children[0].children[1]) {
      playerObj.children[0].children[1].material.opacity = (flashCount % 2 === 0) ? 0.3 : 1.0;
    }
    flashCount++;
    if (flashCount >= 6) {
      clearInterval(flashInterval);
      if (playerObj && playerObj.children[0] && playerObj.children[0].children[1]) {
        playerObj.children[0].children[1].material.opacity = 1.0;
      }
    }
  }, 150);
}

function GameOver() {
  playerLoaded = false;
  ShowGameOverScreen();
  setTimeout(() => { window.location.reload(); }, 3000);
}

function UpdateLivesDisplay() {
  const livesDisplay = document.querySelector('#livesDisplay');
  if (livesDisplay) livesDisplay.textContent = playerLives;
}

function ShowGameOverScreen() {
  const screen = document.querySelector('#gameOverScreen');
  if (screen) {
    screen.style.display = 'flex';
    gsap.fromTo(screen, { opacity: 0 }, { opacity: 1, duration: 0.5 });
  }
}

function ShowWinScreen() {
  const screen = document.querySelector('#winScreen');
  const countElement = document.querySelector('#finalCount');
  if (screen) {
    if (countElement) {
      countElement.textContent = wholesomeCollected;
    }
    screen.style.display = 'flex';
    gsap.fromTo(screen, { opacity: 0 }, { opacity: 1, duration: 0.5 });

    // LoopMe: Track completion event
    trackEvent('complete', {
      score: wholesomeCollected,
      timestamp: Date.now()
    });

    // LoopMe: Wire up CTA button
    const learnMoreBtn = document.getElementById('learnMoreBtn');
    if (learnMoreBtn) {
      learnMoreBtn.addEventListener('click', handleClickThrough);
    }
  }
}

function HideWinScreen() {
  const screen = document.querySelector('#winScreen');
  if (screen) {
    gsap.to(screen, {
      opacity: 0,
      duration: 0.5,
      onComplete: () => {
        screen.style.display = 'none';
      }
    });
  }
}


function moveChar()
{
  if(turning>0)
  {
    angle -= (Math.PI/180)*turnAccel;
    charBody.quaternion.setFromAxisAngle(new CANNON.Vec3(0,1,0),angle);
  }

  if(turning<0)
  {
    angle += (Math.PI/180)*turnAccel;
    charBody.quaternion.setFromAxisAngle(new CANNON.Vec3(0,1,0),angle);
  }  

  if(moving>0)//forward
  {
    speed += acceler;
    if(speed> maxSpeed)
    {
      speed = maxSpeed;
    } 
  }

  if(moving<0)// backward
  {
    speed -= acceler;
    if(speed < minSpeed)
    {
      speed = minSpeed;
    }
  } 

  if(charBody)
  {
    charBody.position.x += speed * Math.sin(-angle);
    charBody.position.z -= speed * Math.cos(-angle);
  }  
}

function lerp (start, end, amt)
{
  return (1-amt)*start+amt*end;
}



let adj = .1;
var target = new THREE.Vector3();
let tarQuat = new THREE.Quaternion();
let lerQuat = new THREE.Quaternion();

//cam spot is 5.7 up and -5 back, rotated 25 down x

function UpdateCam()
{
  if(camSpot)
  {
    camSpot.getWorldPosition(target);
    camSpot.getWorldQuaternion(tarQuat);

    camera.position.x = lerp(camera.position.x,target.x,adj);
    camera.position.y = lerp(camera.position.y,target.y,adj);
    camera.position.z = lerp(camera.position.z,target.z,adj);

    camera.quaternion.slerp(tarQuat,adj);
  }
}

function CreatePortalArrow() {
  const arrowGeometry = new THREE.ConeGeometry(0.3, 1, 3);
  const arrowMaterial = new THREE.MeshStandardMaterial({
    color: 0x00ff00,
    emissive: 0x00ff00,
    emissiveIntensity: 0.5
  });

  portalArrow = new THREE.Mesh(arrowGeometry, arrowMaterial);
  portalArrow.rotation.x = Math.PI / 2;
  portalArrow.position.y = 3;
  portalArrow.parent = playerObj;
  scene.add(portalArrow);
}

function UpdatePortalArrow() {
  if (!portalUnlocked || !portalArrow || !playerObj) return;

  const playerPos = playerObj.position;
  const dx = portalPosition.x - playerPos.x;
  const dz = portalPosition.z - playerPos.z;
  const angleToPortal = Math.atan2(dx, -dz);

  portalArrow.rotation.z = -angleToPortal + playerObj.rotation.y;

  const pulseScale = 1 + Math.sin(Date.now() * 0.003) * 0.2;
  portalArrow.scale.set(pulseScale, pulseScale, pulseScale);
}

function UpdateProductHologram() {
  if (!window.productHologram || !playerObj) return;

  const playerPos = playerObj.position;
  const chestPos = { x: -49, y: 16, z: -40.6 }; // Updated chest position

  // Calculate distance from player to chest
  const dx = chestPos.x - playerPos.x;
  const dz = chestPos.z - playerPos.z;
  const distance = Math.sqrt(dx * dx + dz * dz);

  // Show hologram when player is within 10 units of the chest
  const showDistance = 10;

  if (distance < showDistance) {
    window.productHologram.visible = true;
    if (window.hologramGlow) window.hologramGlow.visible = true;

    // Rotate the hologram smoothly
    window.productHologram.rotation.y += 0.01;

    // Floating animation - bobbing up and down
    const floatOffset = Math.sin(Date.now() * 0.002) * 0.5; // Increased amplitude
    window.productHologram.position.y = 16 + floatOffset; // Updated base height
    if (window.hologramGlow) {
      window.hologramGlow.position.y = 16 + floatOffset;
    }

    // Pulse the glow
    if (window.hologramGlow) {
      const glowPulse = 0.15 + Math.sin(Date.now() * 0.003) * 0.08; // More visible pulse
      window.hologramGlow.material.opacity = glowPulse;
    }
  } else {
    window.productHologram.visible = false;
    if (window.hologramGlow) window.hologramGlow.visible = false;
  }
}



//#region Game Loop
const clock = new THREE.Clock();
let oldElapsedTime = 0;

let trapTar = new THREE.Vector3();
let trapQuat = new THREE.Quaternion();

// LoopMe Ad Pause/Resume API
let isPaused = false;
let animationFrameId = null;

window.LoopMe3DAPI = {
  pause: () => {
    console.log('[LoopMe API] Game paused');
    isPaused = true;
    if (animationFrameId) {
      cancelAnimationFrame(animationFrameId);
      animationFrameId = null;
    }
    clock.stop();
  },
  resume: () => {
    console.log('[LoopMe API] Game resumed');
    isPaused = false;
    clock.start();
    if (!animationFrameId) {
      gameLoop();
    }
  }
};

////main game loop==================================================================
const gameLoop = () =>
{
  if (isPaused) return;

  animationFrameId = requestAnimationFrame(gameLoop);  

  const elapsedTime = clock.getElapsedTime();
  const deltaTime = elapsedTime - oldElapsedTime;
  oldElapsedTime = elapsedTime;

  //update physics world
  world.step(1/60,deltaTime,3);

  if(aniMixers.length>0)
  {
    for(const mix of aniMixers)
    {
      mix.update(deltaTime);
    }
  }

  //cannonDebugger.update();
  
  
  // only the player is in this
  for(const object of objectsToUpdate)
  {        
    object.mesh.position.copy(object.body.position);
    object.mesh.position.y -=1;
    object.mesh.position.z;
    object.mesh.quaternion.copy(object.body.quaternion); 
    object.mesh.rotation.y += Math.PI; 
    // Howler.pos(object.mesh.position.x,0,object.mesh.position.z); // Audio disabled for LoopMe      
  }  

  if(trapsOut)
  {
    for(const trap of trapsToUpdate)
  {    
    trap.body.position.copy(trap.mesh.getWorldPosition(trapTar));
    trap.body.quaternion.copy(trap.mesh.getWorldQuaternion(tarQuat));                  
    }
  }
  moveChar();

  UpdateCam();
  UpdatePortalArrow();
  UpdateProductHologram();

  // stats.update(); // Stats removed for size optimization

  renderer.render(scene,camera);   
}

//call it once to kick off the loop
gameLoop();
////main game loop==================================================================

//#region LoopMe Start Event
// Track ad start when everything is loaded
window.addEventListener('load', () => {
    trackEvent('start', {
        timestamp: Date.now()
    });
    console.log('[LoopMe] Game loaded and start event tracked');
});

// Add canvas click listener for hologram interaction
canvas.addEventListener('click', onCanvasClick);
canvas.addEventListener('touchend', onCanvasClick);
//#endregion LoopMe Start Event
//#endregion Game Loop
